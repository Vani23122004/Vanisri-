year =int(input("Enter a year: "))
if(year% 4 == 0):
 print("The given year is leap year")
else:
 print("The given year is not a leap year")